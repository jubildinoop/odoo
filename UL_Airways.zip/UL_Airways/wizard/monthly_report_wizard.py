# -*- coding: utf-8 -*-
import json

from odoo import api, fields, models, _
from datetime import datetime, date


class MonthlyReportWizard(models.TransientModel):
    _name = "monthly.report.wizard"
    _description = "This is a wizard to print month-wise report"

    month = fields.Selection([
        ('m1', 'January'),
        ('m2', 'February'),
        ('m3', 'March'),
        ('m4', 'April'),
        ('m5', 'May'),
        ('m6', 'June'),
        ('m7', 'July'),
        ('m8', 'August'),
        ('m9', 'September'),
        ('m10', 'October'),
        ('m11', 'November'),
        ('m12', 'December')], string='Select Month')
    flight_id = fields.Many2one('add.flight', string="Flight Name")

    def monthly_report_wizard_button(self):
        print(",,,,,,,")
        for rec in self:
            month_report_val = self.env['flight.details'].search_read([])
            print("monthlyyyyyyyy", month_report_val)
            data = {
                'form': self.read()[0],
                'month_report_val': month_report_val
            }
            return self.env.ref('UL_Airways.action_flight_monthly_report_data').report_action(self, data=data)
