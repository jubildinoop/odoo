# -*- coding: utf-8 -*-
import json

from odoo import api, fields, models, _
from datetime import datetime, date


class SearchFlightWizard(models.TransientModel):
    _name = "search.flight.wizard"
    _description = "This is a wizard to search flights"

    trip_type = fields.Selection([
        ('type1', 'One Way'),
        ('type2', 'Round Trip')], default='type1', string='Trip')
    travelling_date1 = fields.Date(string="Travelling Date")
    travelling_date2 = fields.Date(string="Return Date")
    from_location_id = fields.Many2one('airport.details', string="Travelling From")
    to_location_id = fields.Many2one('airport.details', string="Reached To")
    html_tab = fields.Html(readonly=True, compute='search_compute_function')
    is_rec = fields.Boolean(default=False)
    user_pnr_id = fields.Many2one('res.users', 'Current User', default=lambda self: self.env.uid, readonly=True)

    # pnr_id = fields.Many2one('res.users', 'PNR No', default=lambda self: self.env.uid,
    #                          readonly=True)

    # dept_time = fields.Char(string="Departure Time")
    # arr_time = fields.Char(string="Arrival Time")
    # start = fields.Char(string="Start From")
    # reach = fields.Char(string="Reached To")
    # seats = fields.Char(string="Seating capacity")

    # slot_id_domain = fields.Char(compute='_compute_slot_id_domain', readonly=True, store=False)

    @api.depends('trip_type', 'travelling_date1', 'travelling_date2', 'from_location_id', 'to_location_id')
    def search_compute_function(self):
        for rec in self:
            search_tab = False
            search_val = self.env['flight.details'].search([('dept_time_new', '=', rec.travelling_date1),
                                                            ('start_id', '=', rec.from_location_id.id),
                                                            ('reach_id', '=', rec.to_location_id.id)])

            if search_val:
                rec.is_rec = True

                print("xxxxxxxxxxxxxyyyyyyyy", search_val, rec.is_rec)
                # creating table
                search_tab = """
                <html>
                 <head>
                    <style>
                    table, th, td {
                    border: 1px solid black;
                    }
                    </style>
                </head>
                <body>
                <center>
                <table border="1" style="width:70%">
                <tr>
                <h2>Flight Details</h2>
                </tr>
                <tr>
                <th style="text-align:center;width:30%,padding:10px">Flight Name</th>
                <th style="text-align:center;width:30%,padding:10px">Flight Type</th>
                <th style="text-align:center;width:30%,padding:10px">Departure</th>
                <th style="text-align:center;width:30%,padding:10px">Arrival</th>
                <th style="text-align:center;width:30%,padding:10px">Seating capacity</th>
                </tr>
                """
                for lines in search_val:
                    search_tab += """<tr>
                    <td style="text-align:center;padding:10px">%s</td>
                    <td style="text-align:center;padding:10px">%s</td>
                    <td style="text-align:center;padding:10px">%s</td>
                    <td style="text-align:center;padding:10px">%s</td>
                    <td style="text-align:center;padding:10px">%s</td>
                    """ % (lines.name_id.name, lines.type, lines.dept_time, lines.arr_time, lines.seats)
                search_tab += """
                </body>
                </table>
                </center>
                </html>
                """

            rec.html_tab = search_tab
            print("table dataaaaa1111", rec.html_tab)
            print("dataaa2222222", search_tab)

        # # URL Action
        # menu_val = self.env.ref('UL_Airways.flight_submenu2')
        # return {
        #     'type': 'ir.actions.act_url',
        #     # 'target': 'self',
        #     # 'url': 'http://localhost:8080/web#action=329&model=flight.details&view_type=list&cids=1&menu_val'
        # }

    def book_now_button(self):
        for rec in self:
            # print("user iddddd", rec.user_pnr_id)
            ctx = self._context.copy()

            # ctx.update({'default_pnr_id': rec.user_pnr_id
            #             })
            return {
                'res_model': 'book.ticket',
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'view_id': self.env.ref("UL_Airways.book_ticket_form_view").id,
                'context': ctx
            }

    # def default_get(self, fields):
    #     res = super(SearchFlightWizard, self).default_get(fields)
    #     active_id = self._context.get('active_id')
    #     browse_id = self.env['book.ticket'].browse(active_id)
    #     if active_id:
    #         res['travelling_date'] = browse_id.travelling_date1
    #         res['travelling_from_id'] = browse_id.from_location_id.id
    #         res['travelling_to_id'] = browse_id.to_location_id.id
    #         res['trip_type'] = browse_id.trip_type
    #     return res

    # active_id = self._context.get('active_id')
    # print("active_id---", active_id)
    # search_val = self.env['flight.details'].browse(active_id)
    # print("search_val----", search_val)
    # vals = {
    #     'flight_name': self.flight_name,
    #     'date_from': self.date_from,
    #     'date_to': self.date_to,
    # }
    # search_val.write(vals)

    # ORM Search method
    # for rec in self:
    #     flight = self.env['flight.details'].search([])
    #     print("flightssss", flight)

    # # compute function for domain
    # @api.depends('flight_id')
    # def _compute_slot_id_domain(self):
    #     for rec in self:
    #         rec.slot_id_domain = json.dumps([('dept_time', '=', rec.flight_id.id)])

    # @api.onchange('name_id')
    # def onchange_name_id(self):
    #     for rec in self:
    #         rec.type = rec.name_id and rec.name_id.flight_type or False

    # @api.model
    # def default_get(self, fields):
    #     res = super(SearchFlightWizard, self).default_get(fields)
    #     active_id = self._context.get('active_id')
    #     browse_id = self.env['flight.details'].browse(active_id)
    #     if active_id:
    #         res['name_id'] = browse_id.name_id.id
    #         res['type'] = browse_id.type
    #         res['dept_time'] = browse_id.dept_time
    #         res['arr_time'] = browse_id.arr_time
    #         res['start'] = browse_id.start_id
    #         res['reach'] = browse_id.reach_id
    #         res['seats'] = browse_id.seats
    #     return res
    # @api.onchange('trip_type')
    # def onchange_date1(self):
    #     for rec in self:
    #         rec.travelling_date1 = rec.name_id and rec.name_id.flight_type or False
