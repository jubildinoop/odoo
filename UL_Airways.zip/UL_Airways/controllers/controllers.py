from odoo import http
from odoo.http import request


class PassengerSystem(http.Controller):
    @http.route('/passenger_reg_web', type="http", auth='public', website=True)
    def passenger_reg_form(self):
        return http.request.render('UL_Airways.reg_passenger', {})

    @http.route('/register/passenger', type="http", auth='public', website=True)
    def customer_form_submit(self, **kwargs):
        print("data receivedddd", kwargs)
        data = request.env['passenger.details'].sudo().create({
            'given_name': kwargs.get('given_name'),
            'surname': kwargs.get('surname'),
            'address': kwargs.get('address'),
            'dob': kwargs.get('dob'),
            'email': kwargs.get('email'),
            # 'password': kwargs.get('password'),
            'phone': kwargs.get('phone'),

        })
        vals = {
            'passenger_system': data,
        }
        request.env['res.users'].sudo().create({
            'name': kwargs.get('given_name'),
            'login': kwargs.get('email')
        })
        return request.render("UL_Airways.passenger_form_success", vals)

    # def sign_up_button(self):
    #     print("welcomeeee", self.given_name, self.email)
    #     self.env['res.users'].create({
    #         'name': self.given_name,
    #         'login': self.email
    #     })
