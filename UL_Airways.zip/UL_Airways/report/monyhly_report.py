# -*- coding: utf-8 -*-

from odoo import models


class MonthlyReport(models.AbstractModel):
    _name = 'report.flight_details.month_data_pdf'

