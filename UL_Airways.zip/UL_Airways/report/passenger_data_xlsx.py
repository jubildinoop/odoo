# -*- coding: utf-8 -*-

from odoo import models


class PassengerXlsx(models.AbstractModel):
    _name = 'report.passenger_details.passenger_data_sheet'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, passengers):
        for obj in passengers:
            report_name = obj.given_name
            # One sheet by partner
            sheet = workbook.add_worksheet(report_name[:31])
            bold = workbook.add_format({'bold': True})
            sheet.write(0, 0, obj.given_name, bold)
