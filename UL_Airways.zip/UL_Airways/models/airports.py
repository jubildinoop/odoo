# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date

from odoo.exceptions import ValidationError


class AirportDetails(models.Model):
    _name = "airport.details"
    _description = "This is a Table to manage Airport Details"

    name = fields.Char(string='Sequence', copy=False, readonly=True, default='New')  # field for sequence
    airport_name = fields.Char(string="Airport Name", required=True)
    airport_code = fields.Char(string="Airport Code")
    city = fields.Char(string="City")
    state = fields.Char(string="State")
    country_id = fields.Many2one('res.country', string="Country")

    # Sequence number creation
    @api.model
    def create(self, vals):
        print("lllll", vals)
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('airport_sequence_code') or 'New'
        result = super(AirportDetails, self).create(vals)
        return result

    # name_get function to combine name and seq number
    def name_get(self):
        result = []
        for rec in self:
            name = '[' + rec.name + ']' + rec.airport_name + '-' + rec.airport_code
            result.append((rec.id, name))
        return result

    # sql constarints to print unique hobbies
    _sql_constraints = [
        ('unique_name', 'unique (airport_name)', 'Stop already exist....')
    ]

    # constarints to check case sensitivity of hobbies
    @api.constrains('airport_name')
    def _check_unique_airport_name(self):
        stop_ids = self.search([]) - self

        value = [x.airport_name.lower() for x in stop_ids]

        if self.airport_name and self.airport_name.lower() in value:
            raise ValidationError(_('The combination is already Exist'))

        return True
