# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date

from odoo.exceptions import ValidationError


class PassengerDetails(models.Model):
    _name = "passenger.details"
    _description = "This is a Table to manage Passenger Details"

    name = fields.Char(string='Sequence', copy=False, readonly=True, default='New')  # field for sequence
    given_name = fields.Char(string="Passenger Given Name")
    surname = fields.Char(string="Passenger Surname")
    address = fields.Text(string="Address")
    email = fields.Char(string="Email ID")
    dob = fields.Date(string="Date of Birth")
    age = fields.Integer(compute='_compute_age', string='Age')
    # password = fields.Char(string="Password")
    phone = fields.Char(string="Phone")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('save', 'Saved'), ('cancel', 'Cancelled')], default='draft', string='Status')
    company = fields.Char(string="Company", compute='_compute_company')
    related_user_id = fields.Many2one('res.users')

    # Sequence number creation
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('passenger_sequence_code') or 'New'
        result = super(PassengerDetails, self).create(vals)
        return result

    # onchange function to shoe dept_head on selecting dept
    @api.depends('name')
    def _compute_company(self):
        for rec in self:
            rec.company = "tsunnyjubil@gmail.com"
            # rec.company_id = rec.name and rec.name.company_id or False

    # compute function to find age
    @api.depends('dob')
    def _compute_age(self):
        for record in self:
            today = date.today()
            if record.dob:
                if today > record.dob:
                    record.age = today.year - record.dob.year
                else:
                    record.age = 0
            else:
                record.age = 0

    # Validation error showing for wrong DOB
    @api.constrains('dob')
    def age_check(self):
        today = date.today()
        for rec in self:
            if rec.dob >= today:
                raise ValidationError(_("Sorry, you entered a wrong DOB!"))
            return

    # phone number validation
    @api.constrains('phone')
    def _check_phone_number(self):
        for rec in self:
            if rec.phone and len(rec.phone) != 10:
                raise ValidationError(_("Contact number should contains 10 digits..."))
        return True

    def action_draft(self):
        for rec in self:
            rec.state = 'draft'

    def action_save(self):
        for rec in self:
            # send email when state changed to save
            reg_temp_id = self.env.ref('UL_Airways.passenger_reg_mail_new_template_id').id
            temp = self.env['mail.template'].browse(reg_temp_id)
            temp.send_mail(self.id, force_send=True)
            rec.state = 'save'
            # rainbow_man effect
            return {
                'effect': {
                    'fadeout': 'slow',
                    'message': 'Passenger Saved Successfully!!!!',
                    'type': 'rainbow_man'
                }
            }

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'



