# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date

from odoo.exceptions import ValidationError


class BaggageDetails(models.Model):
    _name = "baggage.details"
    _description = "This is a Table to manage Baggage Details"

    flight_id = fields.Many2one('add.flight', string="Flight Name")
    baggage_type = fields.Selection([
        ('baggage1', 'Hand Carry'),
        ('baggage2', 'Suitcase')], string='Baggage Type')
    dimension = fields.Char(string="Dimension(length + width + height)")
    flight_type = fields.Char(string="Class of Travel")
    baggage_allowance = fields.Selection([
        ('wt1', '35Kg'),
        ('wt2', '40Kg'), ('wt3', '50Kg')], string='Baggage Allowance')
    policy = fields.Html(string="Baggage Policies")

    # onchange function to print
    @api.onchange('flight_id')
    def onchange_flight_id(self):
        for rec in self:
            rec.flight_type = rec.flight_id and rec.flight_id.flight_type or False


class CabinBaggage(models.Model):
    _name = "cabin.baggage"
    _description = "This is a Table to manage Cabin Baggage Rules"

    rule = fields.Html(string="Cabin Baggage Rules")
