# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date

from odoo.exceptions import ValidationError


class AddFlight(models.Model):
    _name = "add.flight"
    _description = "This is a Table to add Flight Details"

    name = fields.Char(string='Flight Code', copy=False, readonly=True, default='New')  # field for sequence
    flt_name = fields.Char(string="Flight Name", required=True)
    flight_type = fields.Selection([
        ('economy', 'Economy Class'),
        ('business', 'Business Class'), ('first', 'First Class')], default='economy', string='Flight Type')
    seats = fields.Integer(string="Seating capacity")
    currency_id = fields.Many2one('res.currency', string='Currency')
    adult_charge = fields.Monetary(string="Ticket Fare for Adults", currency_field='currency_id')
    senior_charge = fields.Monetary(string="Ticket Fare for Senior Citizen", currency_field='currency_id',
                                    compute='_compute_senior_charge', readonly=True)
    child_charge = fields.Monetary(string="Ticket Fare for Child", currency_field='currency_id',
                                   compute='_compute_child_charge', readonly=True)
    infant_charge = fields.Monetary(string="Ticket Fare for Infants", currency_field='currency_id')
    # flight_img = fields.Binary(string="Upload Image")
    # schedule_count = fields.Char(compute='_compute_schedule_count')

    # Sequence number creation
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            print("entered")
            vals['name'] = self.env['ir.sequence'].next_by_code('add_flight_sequence_code') or 'New'
        result = super(AddFlight, self).create(vals)
        return result

    # name_get function to combine name and seq number
    def name_get(self):
        result = []
        for rec in self:
            name = rec.flt_name
            result.append((rec.id, name))
        return result

    # The following two functions for schedule stat button
    # def all_schedule_count(self):
    #     return

    def _compute_senior_charge(self):
        print("valuuuuuuuu", self.adult_charge)
        self.senior_charge = self.adult_charge / 2

    def _compute_child_charge(self):
        print("valuuuuuuuu", self.adult_charge)
        self.child_charge = self.adult_charge / 4

    # def _compute_schedule_count(self):
    #     for rec in self:
    #         print("welcome")
    #         schedule_count = self.env['flight.details'].search_count([('name_id.id', '=', rec.name)])
    #         print("comeeee", schedule_count)
