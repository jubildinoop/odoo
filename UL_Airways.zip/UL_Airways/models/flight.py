# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date

from odoo.exceptions import ValidationError


class FlightDetails(models.Model):
    _name = "flight.details"
    _description = "This is a Table to manage Flight Details"

    name = fields.Char(string='Schedule Reference', copy=False, readonly=True, default='New')  # field for sequence
    name_id = fields.Many2one('add.flight', string="Flight Name", required=True)
    flight_code = fields.Char(string="Flight Reference")
    type = fields.Char(string="Flight Type")
    dept_time = fields.Datetime(string="Departure")
    dept_time_new = fields.Date(compute='_compute_dept_date', store=True)
    arr_time = fields.Datetime(string="Arrival")
    arr_time_new = fields.Date(compute='_compute_arr_date', store=True)
    start_id = fields.Many2one('airport.details', string="Start From")
    reach_id = fields.Many2one('airport.details', string="Reached To")
    stop_ids = fields.Many2many('airport.details', 'stop_data_rel', 'flight_id', 'stop_id', string="Stops")
    seats = fields.Integer(string="Seating capacity")
    seat_left = fields.Integer(string="Remaining Seats")
    trip_type = fields.Selection([
        ('type1', 'One Way'),
        ('type2', 'Round Trip')], default='type1', string='Trip')

    # Sequence number creation
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('flight_sequence_code') or 'New'
        result = super(FlightDetails, self).create(vals)
        return result

    # # name_get function to combine name and seq number
    # def name_get(self):
    #     result = []
    #     for rec in self:
    #         name = rec.name + rec.name_id
    #         result.append((rec.id, name))
    #     return result
    # onchange function to show flight type on selecting flight name

    # onchange function to print flight type on selecting flight name
    @api.onchange('name_id')
    def onchange_type(self):
        for rec in self:
            rec.type = rec.name_id and rec.name_id.flight_type or False
            rec.flight_code = rec.name_id and rec.name_id.name or False

    @api.onchange('name_id')
    def onchange_seat(self):
        for rec in self:
            rec.seats = rec.name_id and rec.name_id.seats or False
            rec.seat_left = rec.seats

    # compute function to find date from date time
    @api.depends('dept_time')
    def _compute_dept_date(self):
        for rec in self:
            if rec.dept_time:
                rec.dept_time_new = rec.dept_time.date()
                print("tiiiiii11111", rec.dept_time_new)

    @api.depends('arr_time')
    def _compute_arr_date(self):
        for rec in self:
            if rec.arr_time:
                rec.arr_time_new = rec.arr_time.date()
                print("tiiiiii22222", rec.arr_time_new)

    # @api.depends('seats')
    # def _compute_seat_left(self):
    #     print("lllll")
    #     for rec in self:
    #         print("kkkkk")
    #         seat_val = self.env['book.ticket'].search([('flight_code', '=', rec.name_id.flt_name)])
    #         print("ffff", seat_val)
    #         if seat_val:
    #             print("jjjjj", seat_val)
    #             rec.seat_left = rec.seats - int(seat_val.total_no_of_passengers)
    #             print("hhhh", rec.seat_left)


