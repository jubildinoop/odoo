# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date

from odoo.exceptions import ValidationError


class GroundStaff(models.Model):
    _name = "ground.staff"
    _description = "This is a Table to manage Ground staff Details"
    _rec_name = "staff_code"

    staff_code = fields.Char(string='Employee Code', copy=False, readonly=True, default='New')  # field for sequence
    name = fields.Char(string="Ground Staff Name", required=True)
    position = fields.Selection([
        ('junior', 'Junior'),
        ('intermediate', 'Trainee'), ('supervisor', 'Supervisor')], string='Job Role')
    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female')], default='male')

    # Sequence number creation
    @api.model
    def create(self, vals):
        if vals.get('staff_code', 'New') == 'New':
            vals['staff_code'] = self.env['ir.sequence'].next_by_code('ground_staff_sequence_code') or 'New'
        result = super(GroundStaff, self).create(vals)
        return result


