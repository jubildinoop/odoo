# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date, timedelta

from odoo.exceptions import ValidationError
import barcode
import barcode.writer
from barcode.writer import ImageWriter
import os
import base64



class BookTicket(models.Model):
    _name = "book.ticket"
    _description = "This is a Table to book tickets"

    name = fields.Char(string='Ticket Sequence', copy=False, readonly=True, default='New')  # field for sequence
    pnr_id = fields.Many2one('passenger.details', string="PNR No", required=True)
    passenger_name1 = fields.Char(string="Passenger Given Name")
    passenger_name2 = fields.Char(string="Passenger Surname")
    age = fields.Integer(string="Age")
    address = fields.Text(string="Address")
    email = fields.Char(string="Email ID")
    phone = fields.Char(string="Mobile No")
    travelling_date = fields.Date(string="Travelling Date")
    return_date = fields.Date(string="Return Date")
    travelling_from_id = fields.Many2one('airport.details', string="Travelling From")
    travelling_to_id = fields.Many2one('airport.details', string="Travelling To")
    adult_no = fields.Selection([
        ('0', '0'),
        ('1', '1'),
        ('2', '2'),
        ('3', '3'),
        ('4', '4'),
        ('5', '5'),
        ('6', '6'),
        ('7', '7'),
        ('8', '8'),
        ('9', '9')
    ], default='0', string='No of Adults(Age between 18-60)')

    senior_no = fields.Selection([
        ('0', '0'),
        ('1', '1'),
        ('2', '2'),
        ('3', '3'),
        ('4', '4'),
        ('5', '5'),
        ('6', '6'),
        ('7', '7'),
        ('8', '8'),
        ('9', '9')
    ], default='0', string='No of Senior Citizen(Age Above 60)')

    child_no = fields.Selection([
        ('0', '0'),
        ('1', '1'),
        ('2', '2'),
        ('3', '3'),
        ('4', '4'),
        ('5', '5'),
        ('6', '6'),
        ('7', '7'),
        ('8', '8'),
        ('9', '9')
    ], default='0', string='No of Child(Age Between 4-17)')

    infant_no = fields.Selection([
        ('0', '0'),
        ('1', '1'),
        ('2', '2'),
        ('3', '3'),
        ('4', '4'),
        ('5', '5'),
        ('6', '6'),
        ('7', '7'),
        ('8', '8'),
        ('9', '9')
    ], default='0', string='No of Infants(Age below 3)')

    total_no_of_passengers = fields.Integer(string="Total Passengers", compute='_compute_total_passengers')
    trip_type = fields.Selection([
        ('type1', 'One Way'),
        ('type2', 'Round Trip')], default='type1', string='Trip')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('book', 'Booked'),
        ('paid', 'Paid'),
        ('cancel', 'Cancelled')], default='draft', string='Status')
    currency_id = fields.Many2one('res.currency', string='Currency Type')
    flight_name = fields.Char(string="Flight Name")
    flight_code = fields.Char(string="Flight Code")
    seats = fields.Integer()
    adult_rate = fields.Monetary(string="Total Fare for adults", currency_field='currency_id',
                                 compute='_compute_adult_fare_sum')
    senior_rate = fields.Monetary(string="Total Fare for Senior Citizens", currency_field='currency_id',
                                  compute='_compute_senior_fare_sum')
    child_rate = fields.Monetary(string="Total Fare for Child", currency_field='currency_id',
                                 compute='_compute_child_fare_sum')
    infant_rate = fields.Monetary(string="Total Fare for Infants", currency_field='currency_id',
                                  compute='_compute_infant_fare_sum')
    total_rate = fields.Monetary(string="Amount to Pay", currency_field='currency_id')
    discounted_rate = fields.Monetary(string="Refunded Amount", currency_field='currency_id')
    company_email = fields.Char(string="Company Email", compute='_compute_company_email')
    schedule_ref = fields.Char(string="Flight Schedule Reference")
    seat_left = fields.Integer(string="Available seats")

    # Sequence number creation
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            print("valsssssss", vals)
            vals['name'] = self.env['ir.sequence'].next_by_code('book_ticket_sequence_code') or 'New'
        result = super(BookTicket, self).create(vals)
        return result

    # onchange function to set company mail
    @api.depends('flight_name')
    def _compute_company_email(self):
        for rec in self:
            rec.company_email = "tsunnyjubil@gmail.com"

    # onchange function to show passenger data on entering PNR no
    @api.onchange('pnr_id')
    def onchange_pnr_id(self):
        for rec in self:
            rec.passenger_name1 = rec.pnr_id and rec.pnr_id.given_name or False
            rec.passenger_name2 = rec.pnr_id and rec.pnr_id.surname or False
            rec.age = rec.pnr_id and rec.pnr_id.age or False
            rec.address = rec.pnr_id and rec.pnr_id.address or False
            rec.email = rec.pnr_id and rec.pnr_id.email or False
            rec.phone = rec.pnr_id and rec.pnr_id.phone or False

    # onchange function to show flight type on selecting flight name
    @api.onchange('travelling_date', 'travelling_from_id', 'travelling_to_id', 'trip_type', 'seat_left')
    def onchange_flight_id(self):
        for rec in self:
            flight_val = self.env['flight.details'].search([('dept_time_new', '=', rec.travelling_date),
                                                            ('start_id', '=', rec.travelling_from_id.id),
                                                            ('reach_id', '=', rec.travelling_to_id.id),
                                                            ('trip_type', '=', rec.trip_type)])
            if rec.travelling_date:
                rec.flight_name = flight_val.name_id.flt_name
                rec.flight_code = flight_val.flight_code
                rec.schedule_ref = flight_val.name
                rec.seat_left = flight_val.seat_left

    # to find total no of passengers
    @api.depends('adult_no', 'senior_no', 'child_no', 'infant_no')
    def _compute_total_passengers(self):
        for rec in self:
            if rec.adult_no and rec.senior_no and rec.child_no and rec.infant_no:
                rec.total_no_of_passengers = int(rec.adult_no) + int(rec.senior_no) + int(rec.child_no) + int(
                    rec.infant_no)

    # def payment_button(self):
    #     for rec in self:
    #         # time1 = rec.dept_time.striptime()
    #         # print("timeeeeee", time1)
    #         previous_date = rec.dept_time - timedelta(days=1)
    #         print("previoussss----", previous_date)

    # onchange function to set currency type based on flight
    @api.onchange('flight_name')
    def onchange_flight_name(self):
        for rec in self:
            currency_val = self.env['add.flight'].search([('flt_name', '=', rec.flight_name)])
            if rec.flight_name:
                rec.currency_id = currency_val.currency_id.id

    # total ticket rate for adults
    @api.depends('adult_no')
    def _compute_adult_fare_sum(self):
        for rec in self:
            adult_fare = self.env['add.flight'].search([('name', '=', rec.flight_code)])
            if rec.adult_no:
                rec.adult_rate = adult_fare.adult_charge * float(rec.adult_no)

    # total ticket rate for seniors
    @api.depends('senior_no')
    def _compute_senior_fare_sum(self):
        for rec in self:
            senior_fare = self.env['add.flight'].search([('name', '=', rec.flight_code)])
            if rec.senior_no:
                rec.senior_rate = senior_fare.senior_charge * float(rec.senior_no)

    # total ticket rate for child
    @api.depends('child_no')
    def _compute_child_fare_sum(self):
        for rec in self:
            child_fare = self.env['add.flight'].search([('name', '=', rec.flight_code)])
            if rec.child_no:
                rec.child_rate = child_fare.child_charge * float(rec.child_no)

    # total ticket rate for infant
    @api.depends('infant_no')
    def _compute_infant_fare_sum(self):
        for rec in self:
            infant_fare = self.env['add.flight'].search([('name', '=', rec.flight_code)])
            if rec.infant_no:
                rec.infant_rate = infant_fare.infant_charge * float(rec.infant_no)

    # to find total rate
    @api.onchange('adult_rate', 'senior_rate', 'child_rate', 'infant_rate')
    def onchange_total_rate(self):
        for rec in self:
            if rec.adult_rate and rec.senior_rate and rec.child_rate:
                rec.total_rate = rec.adult_rate + rec.senior_rate + rec.child_rate + rec.infant_rate

    # button for payment
    def button_payment_action(self):
        for rec in self:
            rec.state = 'paid'
            ctx = self._context.copy()

            ctx.update({'default_ref': rec.name,
                        'default_pnr_no' : rec.pnr_id.id,
                        'default_passenger_name' : rec.passenger_name1,
                        'default_email' : rec.email,
                        'default_phone' : rec.phone,
                        'default_travel_date' : rec.travelling_date,
                        'default_flight' : rec.flight_name,
                        'default_departure' : rec.travelling_from_id.airport_name,
                        'default_no_of_passengers' : rec.total_no_of_passengers,
                        'default_amount' : rec.total_rate
                        })
            return {
                'res_model': 'account.move',
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'view_id': self.env.ref("account.view_move_form").id,
                'context': ctx
            }

    def action_draft(self):
        for rec in self:
            rec.state = 'draft'

    def action_book(self):
        for rec in self:
            # send email when state changed to book
            book_temp_id = self.env.ref('UL_Airways.passenger_ticket_book_mail_template_id').id
            temp = self.env['mail.template'].browse(book_temp_id)
            temp.send_mail(self.id, force_send=True)
            rec.state = 'book'
            if rec.state == 'book':
                print("boookkkkk")
                seat_val = self.env['flight.details'].search([('flight_code', '=', rec.flight_code)])
                print("seatssssss", seat_val, seat_val.seat_left)
                seat_val.seat_left = seat_val.seat_left - rec.total_no_of_passengers
                print("new vallll", seat_val.seat_left)

    def action_cancel(self):
        for rec in self:
            cancel_temp_id = self.env.ref('UL_Airways.passenger_ticket_cancel_mail_template_id').id
            temp1 = self.env['mail.template'].browse(cancel_temp_id)
            temp1.send_mail(self.id, force_send=True)
            rec.state = 'cancel'
            print("hiiiii")
            if rec.state == 'cancel':
                rec.discounted_rate = (rec.total_rate - (rec.total_rate * 0.15))

    def scheduled_remainder_travel(self):
        for rec in self:
            print("travel date", rec.travelling_date)
            yesterday = rec.travelling_date - timedelta(days=1)
            print("Yesterday was: ", yesterday)

    # print barcode for booked ticket

    def print_barcode_button(self):
        for rec in self:
            return self.env.ref('UL_Airways.action_ticket_barcode_print').report_action(self)


class AccountMove(models.Model):
    _inherit = 'account.move'

    pnr_no = fields.Char(string="PNR No")
    passenger_name = fields.Char(string="Passenger Name")
    email = fields.Char(string="Passenger Email")
    phone = fields.Char(string="Contact No")
    travel_date = fields.Char(string="TRavelling Date")
    flight = fields.Char(string="Flight")
    departure = fields.Char(string="Airport")
    no_of_passengers = fields.Char(string="Total Passengers")
    amount = fields.Char(string="Amount to Pay")
