# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import datetime, date


class CreateAppointmentWizard(models.TransientModel):
    _name = "create.appointment.wizard"
    _description = "This is a wizard to create appointment with HOD"

    stud_name = fields.Char(string="Student")
    department_id = fields.Many2one('department.details', string="Department")
    dept_head = fields.Char(string="HOD")
    appointment_date = fields.Date(string="Appointment Date")
    cls = fields.Char(string="Class")
    r_no = fields.Char(string="Roll No")
    age = fields.Char(string="Age")
    stay = fields.Char(string="Is Hosteller?")
    gender = fields.Char(string='Gender')
    dob = fields.Char(string="DOB")
    phone = fields.Char("Phone No")
    school_type = fields.Selection([
        ('lp', 'LP'),
        ('up', 'UP'),
        ('hs', 'HS'),
        ('hss', 'HSS')])
    hobby_ids = fields.Many2many('student.hobbies', 'stud_hobby_upd_rel', 'stud_upd_id', 'hob_upd_id')

    @api.onchange('department_id')
    def onchange_department_id(self):
        for rec in self:
            rec.dept_head = rec.department_id and rec.department_id.dept_head or False

    def create_appointment_wizard_button(self):
        active_id = self._context.get('active_id')
        hod_date = self.env['student.details'].browse(active_id)
        vals = {
            'stud_name': self.stud_name,
            'department_id': self.department_id,
            'dept_head': self.dept_head,
            'std': self.cls,
            'roll': self.r_no,
            'age': self.age,
            'stay_check': self.stay,
            'gender': self.gender,
            'date_of_birth': self.dob,
            'contact_no': self.phone,
            'school_type': self.school_type,
            'hobby_ids': self.hobby_ids,
            'appointment_date': self.appointment_date
        }
        hod_date.write(vals)

    @api.model
    def default_get(self, fields):
        res = super(CreateAppointmentWizard, self).default_get(fields)
        active_id = self._context.get('active_id')
        browse_id = self.env['student.details'].browse(int(active_id))
        if active_id:
            res['stud_name'] = browse_id.name
            res['department_id'] = browse_id.department_id.id
            res['dept_head'] = browse_id.dept_head
            res['cls'] = browse_id.std
            res['r_no'] = browse_id.roll
            res['age'] = browse_id.age
            res['stay'] = browse_id.stay_check
            res['gender'] = browse_id.gender
            res['dob'] = browse_id.date_of_birth
            res['phone'] = browse_id.contact_no
            res['school_type'] = browse_id.school_type
            res['hobby_ids'] = browse_id.hobby_ids
        return res
