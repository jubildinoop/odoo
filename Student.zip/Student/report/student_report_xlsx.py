from odoo import models, fields, api, tools


class StudentCardXlsx(models.AbstractModel):
    _name = 'report.Student.student_card'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, students):
        # for rec in students:
        report_name = "student"

        sheet = workbook.add_worksheet(report_name)
        bold = workbook.add_format({'bold': True, 'font_color': 'blue'})
        date_style = workbook.add_format({'text_wrap': True, 'num_format': 'dd-mm-yyyy'})
        row = 0
        col = 0
        sheet.set_column('C:D', 20)

        domain = []
        if data['form']['date']:
            domain.append(('date_of_birth', '<', data['form']['date']))

        student = self.env['student.details'].search(domain)
        for students in student:
            row = row + 1
            col = 0
            sheet.write(0, 0, 'NAME', bold)
            sheet.write(row, col, students.stud_name)
            col = col + 1
            sheet.write(0, 1, 'AGE', bold)
            sheet.write(row, col, students.age)
            col = col + 1
            sheet.write(0, 2, 'DOB', bold)
            sheet.write(row, col, students.date_of_birth, date_style)
            col = col + 1
            sheet.write(0, 3, 'EMAIL', bold)
            sheet.write(row, col, students.email)
            col = col + 1

# single record report
# sheet.write(row, col, data['form']['age'], bold)
# sheet.write(0,0,'Name')
# sheet.write(1,0,students.stud_name)
# sheet.write(0,1,'Age')
# sheet.write(1,1,students.age)
# sheet.merge_range('C1:D1', report_name, bold)
# sheet.write(0,2,'Email')
# # sheet.merge_range(, report_name, bold)'C1:D1'
# sheet.write(1,2,students.email_id)
# # sheet.write(0,3,'department')
# # sheet.write(1,3,students.department_id)

