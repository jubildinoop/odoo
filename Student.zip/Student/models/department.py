# -*- coding: utf-8 -*-
from odoo import api, fields, models
from datetime import datetime, date


class DepartmentDetails(models.Model):
    _name = "department.details"
    _description = "This is a Table to manage Departments"

    department_id = fields.Integer(string='Id of department')
    name = fields.Char(string='Name of Department', required=True)
    dept_head = fields.Char(string="Name of Department Head")
    related_user_id = fields.Many2one('res.users')
