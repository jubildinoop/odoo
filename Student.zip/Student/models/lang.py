# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import datetime, date

from odoo.exceptions import ValidationError


class StudentLng(models.Model):
    _name = "student.lng"
    _description = "This is a table to manage Student languages"

    langtab_id = fields.Many2one('lang.tab', string='Languages', ondelete='cascade')  # ondelete
    # =cascade, will delete records related to one which we are deleting
    name = fields.Char(string="Languages Known")
    is_read = fields.Boolean(string="Read")
    is_write = fields.Boolean(string="Write")
    is_speak = fields.Boolean(string="Speak")
    student_id = fields.Many2one('student.details')

    # @api.onchange('langtab_id')
    # def _onchange_langtab_id(self):
    #     domain = {'langtab_id': [('id', '=', self.langtab_id)]}
    #     return {'domain': domain}


class LangTab(models.Model):
    _name = "lang.tab"
    _description = "This is a table to manage languages"

    id = fields.Char(string='Id of language')
    name = fields.Char(string="Languages Known")

    # # sql constarints to print unique languages
    # _sql_constraints = [
    #     ('unique_name', 'unique (name)', 'Language already exist....')
    # ]
    #
    # # constarints to check case sensitivity of languages
    # @api.constrains('name')
    # def _check_unique_language(self):
    #     lang_ids = self.search([]) - self
    #
    #     value = [x.name.lower() for x in lang_ids]
    #
    #     if self.name and self.name.lower() in value:
    #         raise ValidationError(_('The combination is already Exist'))
    #
    #     return True
