# -*- coding: utf-8 -*-
from odoo import api, fields, models
from datetime import datetime, date


class StudentSubject(models.Model):
    _name = "student.subject"
    _description = "This is a Table to manage Subjects and Marks"

    subject_id = fields.Integer(string='Subject ID')
    name = fields.Char(string='Subjects', required=True)


class SubjectSubject(models.Model):
    _name = 'subject.subject'

    subject_id = fields.Many2one('student.subject')
    mark = fields.Integer(string='Enter mark')
    student_id = fields.Many2one('student.details')
