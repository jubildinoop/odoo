# -*- coding: utf-8 -*-
import re

from odoo import api, fields, models, _
from datetime import datetime, date
from odoo.exceptions import ValidationError


class StudentDetails(models.Model):
    _name = "student.details"
    _description = "This is a Table to manage Student Details"
    _order = "std asc"

    stud_name = fields.Char(string='Name of Student', placeholder='Name of Student')
    roll = fields.Char(string='Roll no of Student', copy=False)  # copy=False, field roll will not appear in the
    # duplicate copy
    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female')], default='male')
    date_of_birth = fields.Date(string='Date of Birth')
    age = fields.Integer(compute='_compute_age', string='Age')
    std = fields.Char(string='Class')
    email = fields.Char(string='Email')
    address = fields.Text(string='Address')
    pic = fields.Binary(string="Upload Image")
    stay_check = fields.Boolean(string="Is Hosteller?")
    school_type = fields.Selection([
        ('lp', 'LP'),
        ('up', 'UP'),
        ('hs', 'HS'),
        ('hss', 'HSS')])
    department_id = fields.Many2one('department.details', help='This is a field shows department to which the student '
                                                               'belongs to', ondelete='restrict')  # ondelete
    # =restrict, we can't delete the department from 'department.details' model because it is accessed here
    dept_head = fields.Char(string='Department Head')
    hobby_ids = fields.Many2many('student.hobbies', 'stud_hobby_rel', 'stud_id', 'hob_id')
    lang_ids = fields.One2many('student.lng', 'student_id')
    subject_ids = fields.One2many('subject.subject', 'student_id')
    body = fields.Html('Description')
    contact_no = fields.Char(string='Contact No')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('save', 'Saved'), ('done', 'Done'), ('cancel', 'Cancelled')], default='draft', string='Status')
    is_birthday = fields.Boolean(string="Birthday?", compute='_compute_is_birthday')
    appointment_date = fields.Char(string="Appointment with HOD on")
    name = fields.Char(string='Sequence', copy=False, readonly=True, default='New')  # field for sequence
    time_to_leave = fields.Date(string="Last dat at school")
    active = fields.Boolean(string="Active", default=True)
    related_user_id = fields.Many2one('res.users')

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('student_sequence_code') or 'New'
        result = super(StudentDetails, self).create(vals)
        return result

    # onchange function to shoe dept_head on selecting dept
    @api.onchange('department_id')
    def onchange_department_id(self):
        for rec in self:
            rec.dept_head = rec.department_id and rec.department_id.dept_head or False

    # compute function to find age
    @api.depends('date_of_birth')
    def _compute_age(self):
        for record in self:
            today = date.today()
            if record.date_of_birth:
                if today > record.date_of_birth:
                    record.age = today.year - record.date_of_birth.year
                else:
                    record.age = 0
            else:
                record.age = 0

    # Validation error showing for wrong DOB
    @api.constrains('date_of_birth')
    def age_check(self):
        today = date.today()
        for rec in self:
            if rec.date_of_birth >= today:
                raise ValidationError(_("Sorry, you entered a wrong DOB!"))
            return

    # phone number validation
    @api.constrains('contact_no')
    def _check_phone_number(self):
        for rec in self:
            if rec.contact_no and len(rec.contact_no) != 10:
                raise ValidationError(_("Contact number should contains 10 digits..."))
        return True

    @api.depends('date_of_birth')
    def _compute_is_birthday(self):
        for rec in self:
            is_birthday = False
            if rec.date_of_birth:
                today = date.today()
                if today.day == rec.date_of_birth.day and today.month == rec.date_of_birth.month:
                    is_birthday = True
            rec.is_birthday = is_birthday

    # mail template function
    def action_send_mail(self):
        # print("sending email")
        template_id = self.env.ref('Student.email_template_student_card').id
        print("sending mail", template_id)
        # print("template id",template_id)
        template = self.env['mail.template'].browse(template_id)
        template.send_mail(self.id, force_send=True)
        # print("template",template)
        # self.env['mail.template'].browse(template_id).send_mail(self.id,force_send=True)

    # cron job to print Good morning
    @api.model
    def notify_wish(self):
        print("Good morning")

    # to print report
    def print_xlsx(self):
        for rec in self:
            data = {
                'ids': rec.ids,
                'model': rec._name,
                'form': {

                    'Name': rec.stud_name,
                    'age': rec.age,
                    'date': rec.date_of_birth,
                    'email': rec.email

                }
            }
            return self.env.ref('Student.student_xlsx_report').report_action(self, data=data)

    def print_report(self):
        # docids = self.env['sale.order'].search([]).ids
        # data = self
        return self.env.ref('Student.student_pdf').report_action(self)

    def action_draft(self):
        for rec in self:
            rec.state = 'draft'

    def action_save(self):
        for rec in self:
            rec.state = 'save'

    def action_done(self):
        for rec in self:
            rec.state = 'done'

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'
