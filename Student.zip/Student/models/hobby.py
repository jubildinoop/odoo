# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import datetime, date

from odoo.exceptions import ValidationError


class StudentHobbies(models.Model):
    _name = "student.hobbies"
    _description = "This is a table to manage Student hobbies"

    name = fields.Char(string="Enter hobbies")

    # sql constarints to print unique hobbies
    _sql_constraints = [
        ('unique_name', 'unique (name)', 'Hobby already exist....')
    ]

    # constarints to check case sensitivity of hobbies
    @api.constrains('name')
    def _check_unique_name(self):
        hobby_ids = self.search([]) - self

        value = [x.name.lower() for x in hobby_ids]

        if self.name and self.name.lower() in value:
            raise ValidationError(_('The combination is already Exist'))

        return True
