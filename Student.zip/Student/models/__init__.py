from . import studnet
from . import hobby
from . import department
from . import lang
from . import subject
