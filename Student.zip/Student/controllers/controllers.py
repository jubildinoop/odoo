from odoo import http
from odoo.http import request


class StudSystem(http.Controller):
    @http.route('/student_reg_web', type="http", auth='public', website=True)
    def student_reg_form(self):
        return http.request.render('Student.reg_student', {})

    @http.route('/register/student', type="http", auth='public', website=True)
    def customer_form_submit(self, **kwargs):
        data = request.env['student.details'].sudo().create({
            'stud_name': kwargs.get('stud_name'),
            'email': kwargs.get('email'),

        })
        vals = {
            'stud_system': data,
        }
        return request.render("Student.student_form_success", vals)
